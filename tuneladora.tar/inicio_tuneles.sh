#!/bin/ksh

ping -c 4 10.111.1.1 > /dev/null


if [ $? -eq 0 ]; then
nohup /home/dmolinao/scripts/tunel.sh -h ingenico -l 8081 > /dev/null;  ##INGENICO
nohup /home/dmolinao/scripts/tunel.sh -h pepephone -l 8082 > /dev/null;  ##PEPEPHONE
nohup /home/dmolinao/scripts/tunel.sh -h infojobs -l 8083 > /dev/null;  #INFOJOBS
nohup /home/dmolinao/scripts/tunel.sh -h dkv -l 8084 > /dev/null;  #DKV
nohup /home/dmolinao/scripts/tunel.sh -h maxip -l 8085 > /dev/null;  ##MAXIPISTA
nohup /home/dmolinao/scripts/tunel.sh -h 10.34.8.250  -l 8086 > /dev/null; ##LBJ
nohup /home/dmolinao/scripts/tunel.sh -h 10.34.0.200 -l 8087 > /dev/null;  ##SH130
nohup /home/dmolinao/scripts/tunel.sh -h 10.34.12.172 -l 8088 > /dev/null;  ##NTE
ex